export default {
  "data": [{
    "id":1,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":2,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":3,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":4,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":5,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":6,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":7,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":8,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":9,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":10,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },{
    "id":11,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":12,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":13,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    },
    {
    "id":14,
    "name": "解放军",
    "sex": "男",
    "studentNo": "201262280033",
    "post": "班长",
    "interest": "为人民服务"
    }
  ]
}
